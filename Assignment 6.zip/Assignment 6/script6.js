// Select the form element
const form = document.querySelector('form');

// Add an event listener for form submission
form.addEventListener('submit', (event) => {
  // Prevent the form from submitting and refreshing the page
  event.preventDefault();

  // Get the values of the form fields
  const name = form.querySelector('#name').value;
  const email = form.querySelector('#email').value;
  const username = form.querySelector('#username').value;
  const phone = form.querySelector('#phone').value;
  const address = form.querySelector('#address').value;
  const education = form.querySelector('#education').value;
  const skills = form.querySelector('#skills').value;
  const interests = form.querySelector('#interests').value;

  // Validate the form data
  if (!name || !email || !username || !phone || !address || !education || !skills || !interests) {
    alert('Please fill in all fields.');
    return;
  }

  // Submit the form data to the server
  const data = {
    name,
    email,
    username,
    phone,
    address,
    education,
    skills,
    interests
  };

  // Use fetch() or another method to send the data to the server
  // Example:
  fetch('/submit-form', {
    method: 'POST',
    body: JSON.stringify(data),
    headers: {
      'Content-Type': 'application/json'
    }
  })
  .then(response => response.json())
  .then(data => {
    console.log('Form data submitted successfully:', data);
    // Optionally, redirect the user to a confirmation page or display a success message
  })
  .catch(error => {
    console.error('Error submitting form data:', error);
    // Optionally, display an error message to the user
  });
});
