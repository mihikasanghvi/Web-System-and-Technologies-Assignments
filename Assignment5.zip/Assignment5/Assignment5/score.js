// Define variables
const quizContainer = document.getElementById("quiz-container");
const questionContainer = document.getElementById("question-container");
const submitButton = document.getElementById("submit-btn");

let currentQuestion = 0;
let score = 0;

// Display the question and choices
function showQuestion() {
  const xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const question = JSON.parse(xhr.responseText).question;
      questionContainer.innerHTML = `
        <h2>${question.question}</h2>
        ${question.choices.map((choice, index) => `
          <label>
            <input type="radio" name="answer" value="${index}" required>
            ${choice}
          </label>
        `).join("")}
      `;
    }
  };
  xhr.open("GET", `quiz.php?currentQuestion=${currentQuestion}`, true);
  xhr.send();
}

// Check the answer and display the result
function checkAnswer(event) {
  event.preventDefault();
  const answer = Number(document.querySelector('input[name="answer"]:checked').value);
  const xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const result = JSON.parse(xhr.responseText).result;
      if (result === "correct") {
        score++;
      }
      currentQuestion++;
      if (currentQuestion === questions.length) {
        showResult();
      } else {
        showQuestion();
      }
    }
  };
  xhr.open("POST", "quiz.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.send(`answer=${answer}&currentQuestion=${currentQuestion}`);
}

// Display the quiz result
function showResult() {
  quizContainer.innerHTML = `
    <h2>Your score is ${score} out of ${questions.length}!</h2>
    <button onclick="location.reload()">Try Again</button>
  `;
}

// Start the quiz
showQuestion();
submitButton.addEventListener("click", checkAnswer);
