<?php

// Define quiz questions
$questions = array(
  array(
    "question" => "What is the capital of France?",
    "choices" => array("Paris", "Berlin", "Madrid"),
    "correctAnswer" => 0
  ),
  array(
    "question" => "What is the tallest mountain in the world?",
    "choices" => array("Mount Everest", "Mount Kilimanjaro", "Mount Fuji"),
    "correctAnswer" => 0
  ),
  array(
    "question" => "What is the largest country by area?",
    "choices" => array("Russia", "China", "United States"),
    "correctAnswer" => 0
  )
);

// Get the submitted answer and check if it is correct
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $answer = $_POST["answer"];
  $currentQuestion = $_POST["currentQuestion"];
  if ($answer == $questions[$currentQuestion]["correctAnswer"]) {
    $result = "correct";
  } else {
    $result = "incorrect";
  }
  echo json_encode(array("result" => $result));
  exit;
}

// Get the current question and display it
if ($_SERVER["REQUEST_METHOD"] == "GET") {
  $currentQuestion = $_GET["currentQuestion"];
  $question = $questions[$currentQuestion];
  echo json_encode(array("question" => $question));
  exit;
}

?>
