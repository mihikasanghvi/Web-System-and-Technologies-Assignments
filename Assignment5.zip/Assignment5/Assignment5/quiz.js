// Define quiz questions
const questions = [
    {
      question: "What is the capital of France?",
      choices: ["Paris", "Berlin", "Madrid"],
      correctAnswer: 0
    },
    {
      question: "What is the tallest mountain in the world?",
      choices: ["Mount Everest", "Mount Kilimanjaro", "Mount Fuji"],
      correctAnswer: 0
    },
    {
      question: "What is the largest country by area?",
      choices: ["Russia", "China", "United States"],
      correctAnswer: 0
    }
  ];
  
  // Define variables
  const quizContainer = document.getElementById("quiz-container");
  const questionContainer = document.getElementById("question-container");
  const submitButton = document.getElementById("submit-btn");
  
  let currentQuestion = 0;
  let score = 0;
  
  // Display the questions and choices
  function showQuestions() {
    const question = questions[currentQuestion];
    questionContainer.innerHTML = `
      <h2>${question.question}</h2>
      ${question.choices.map((choice, index) => `
        <label>
          <input type="radio" name="answer" value="${index}" required>
          ${choice}
        </label>
      `).join("")}
    `;
  }
  
  // Check the answer and display the result
  function checkAnswer() {
    const answer = Number(document.querySelector('input[name="answer"]:checked').value);
    if (answer === questions[currentQuestion].correctAnswer) {
      score++;
    }
    currentQuestion++;
    if (currentQuestion === questions.length) {
      showResult();
    } else {
      showQuestions();
    }
  }
  
  // Display the result
  function showResult() {
    quizContainer.innerHTML = `
      <h1>Quiz Result</h1>
      <p>You scored ${score} out of ${questions.length} questions.</p>
    `;
  }
  
  // Submit the quiz
  function submitQuiz(event) {
    event.preventDefault();
    checkAnswer();
  }
  
  // Add event listener to the submit button
  submitButton.addEventListener("click", submitQuiz);
  
  // Show the first question
  showQuestions();
  