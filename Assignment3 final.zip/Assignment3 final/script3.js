	// Global variables
	var slideIndex = 1;
	var timerIntervalId;
	var isAutoplayOn = false;
	var timerSpeed = 5000;

	// Show initial slide
	showSlides(slideIndex);

	// Functions for navigating the slideshow
	function plusSlides(n) {
		showSlides(slideIndex += n);
	}

	function currentSlide(n) {
		showSlides(slideIndex = n);
	}

	function showSlides(n) {
		var i;
		var slides = document.getElementsByClassName("slide");
		var dots = document.getElementsByClassName("dot");
		if (n > slides.length) {slideIndex = 1}
		if (n < 1) {slideIndex = slides.length}
		for (i = 0; i < slides.length; i++) {
			slides[i].style.display = "none";
		}
		for (i = 0; i < dots.length; i++) {
			dots[i].className = dots[i].className.replace(" active", "");
		}
		slides[slideIndex-1].style.display = "block";
		dots[slideIndex-1].className += " active";
	}

	// Functions for timer controls
	function updateTimerSpeed() {
		timerSpeed = 1000 * document.getElementById("timer-speed").value;
		document.getElementById("timer-speed-label").textContent = timerSpeed / 1000 + "s";
		if (isAutoplayOn) {
			clearInterval(timerIntervalId);
			timerIntervalId = setInterval(plusSlides.bind(null, 1), timerSpeed);
		}
	}

	function toggleAutoplay() {
		if (isAutoplayOn) {
			clearInterval(timerIntervalId);
			document.getElementById("toggle-autoplay").textContent = "Autoplay: OFF";
		} else {
			timerIntervalId = setInterval(plusSlides.bind(null, 1), timerSpeed);
			document.getElementById("toggle-autoplay").textContent = "Autoplay: ON";
		}
		isAutoplayOn = !isAutoplayOn;
	}

